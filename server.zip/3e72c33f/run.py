from flask import Flask, render_template, request, redirect, url_for, send_from_directory, jsonify, abort, session
import os
import sys
import threading
import shutil
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'files')
BACKUP_FOLDER = os.path.join(os.getcwd(), 'backups')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
if not os.path.exists(BACKUP_FOLDER):
    os.makedirs(BACKUP_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def login():
    return render_template('login.html', app_key=app_key)

@app.route('/validate_key', methods=['POST'])
def validate_key():
    entered_key = request.form.get('key')
    if entered_key == app_key:
        session['authenticated'] = True
        return redirect(url_for('index'))
    else:
        return "Invalid key. Please try again.", 400

@app.before_request
def require_login():
    allowed_routes = ['login', 'validate_key', 'static']
    if request.endpoint not in allowed_routes and not session.get('authenticated'):
        return redirect(url_for('login'))

@app.route('/index', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return "No file part", 400
        files = request.files.getlist('file')
        for file in files:
            if file.filename:
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))
        return redirect(url_for('index'))
    return render_template('index.html')

@app.route('/files')
def list_files():
    page = int(request.args.get('page', 1))
    files = os.listdir(app.config['UPLOAD_FOLDER'])
    files_per_page = 10
    paginated_files = files[(page - 1) * files_per_page : page * files_per_page]
    return jsonify(paginated_files)

@app.route('/files/<filename>')
def download_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)

@app.route('/delete/<filename>', methods=['POST'])
def delete_file(filename):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if os.path.exists(file_path):
        os.remove(file_path)
        return redirect(url_for('index'))
    else:
        abort(404, description="File not found")

@app.route('/rename/<filename>', methods=['POST'])
def rename_file(filename):
    new_name = request.form.get('new_name')
    if not new_name:
        return "New name is required", 400
    old_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    new_path = os.path.join(app.config['UPLOAD_FOLDER'], new_name)
    if os.path.exists(old_path):
        os.rename(old_path, new_path)
        return redirect(url_for('index'))
    else:
        abort(404, description="File not found")

@app.route('/shutdown', methods=['POST'])
def shutdown():
    func = request.environ.get('werkzeug.server.shutdown')
    if func:
        func()
    else:
        os._exit(0)
    return 'Server shutting down...'

def run_app():
    app.run(host='192.168.0.120', port=8000)

def read_key_from_file():
    key_file = "key.txt"
    if os.path.exists(key_file):
        with open(key_file, 'r') as file:
            return file.readline().strip()
    else:
        sys.exit(1)

def listen_for_stop():
    while True:
        user_input = input("Type 'stop' to shut down the server: ")
        if user_input.lower() == 'stop':
            os._exit(0)

def backup_files():
    if len(os.listdir(UPLOAD_FOLDER)) >= 5:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(BACKUP_FOLDER, f"backup_{timestamp}")
        shutil.copytree(UPLOAD_FOLDER, backup_path)
        print(f"Backup created at {backup_path}")
    else:
        print("Backup skipped: Less than 5 files in the folder.")
    threading.Timer(12 * 60 * 60, backup_files).start()

if __name__ == '__main__':
    app_key = read_key_from_file()
    threading.Thread(target=run_app, daemon=True).start()
    backup_files()
    listen_for_stop()
